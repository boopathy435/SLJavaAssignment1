package com;

import java.math.BigInteger;
import java.util.Random;
import java.util.Scanner;

public class Prime {

	static int checkPrimeBigInt(int n) {
		System.out.println("***BigInteger***");
		BigInteger i = new BigInteger(String.valueOf(n));
		return Integer.parseInt(i.nextProbablePrime().toString());
	}
	static int checkPrime(int n) {
		System.out.println("***Manual***");
		int i,count=0;
		if(n>0) {
			
			while(count==0) {
				count=1;
				for(i=2;i<=n/2;i++) {
					if(n%i==0) {
						count=0;
						break;
					}
				}
				if(count==0) {
				n++;
			}}
		}
		return n;
		
			}
	
	public static void main(String[] args) {
			System.out.println("Enter a number to find the next prime number:");
			Scanner sc = new Scanner(System.in);
			int number = sc.nextInt();
			sc.close();

			Random r = new Random();
			if(r.nextBoolean()) {
				System.out.println("Next Prime number is:"+checkPrimeBigInt(number));
			}else {
				System.out.println("next Prime number is:"+checkPrime(number));
			}
			
			
		
	}

}
