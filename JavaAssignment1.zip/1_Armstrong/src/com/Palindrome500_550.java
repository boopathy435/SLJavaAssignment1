package com;

public class Palindrome500_550 {

	public static void main(String[] args) {

		int check=0,count=0,sum=0;
		for(int i=500;i<=550;i++) {
			
			check=i;
			count=0;
			//System.out.println("passed num:"+i);
			while(check>0) {
				check/=10;
				count++;
			}
			//System.out.println(i+" count:"+count);
			
			check=i;
			sum=0;
			while(count>0) {
				sum+=((check%10)*Math.pow(10, count-1));
				check/=10;
				count--;
			}
			//System.out.println("sum:"+sum);
			if(sum==i) {
				System.out.println(i);
			}
			
		}
	}

}
