package com;

public class AvgPrimeNo50_150 {

	public static void main(String[] args) {

		int check=0,count=0;
		double sum=0,no=0;
		for(int i=50;i<=150;i++) {
			
			check=i;
			check/=2;
			count=0;
			while(check>1) {
				if(i%check==0) {
					count++;
				}
				check--;
			}
			if(count==0) {
				System.out.println(i);
				sum+=i;
				no++;
			}
		}
		System.out.println("Avg of Prime Number"+Math.round((sum/no)*100)/100);
		
		
	}

}
