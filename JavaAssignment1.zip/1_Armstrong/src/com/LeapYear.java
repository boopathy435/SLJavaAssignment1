package com;

public class LeapYear {

	public static void main(String[] args) {
		int leapyear,i,j;
		for(i=2000;i<=2200;i++) {
			if(i%4==0) {
				if(i%100==0) {
					if(i%400==0) {
						System.out.println(i);
					}
				}else {
					System.out.println(i);
				}
			}
		}
		
	}

}
