package com;

public class AllArmstrong1000 {

	public static void main(String[] args) {
int count=0,j=0,sum=0,check;
		for(int i=1;i<1000;i++) {
			//System.out.println("Passing number:"+i);
			count=0;
			check=i;
			while(check>0) {
				check/=10;
				count++;
			}
			//System.out.println("Count:"+count);
			sum=0;
			check=i;
			while(count>0) {
				if(check>9) {
				j=check%10;}else {
				j=check;	
				}
				
				sum+=Math.pow(j, 3);
				check/=10;
				count--;
			}
			if(sum==i) {
				System.out.println(i);
			}
		}
		
	}

}
