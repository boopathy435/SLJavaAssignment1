package com;

import java.util.Scanner;

public class Strong {
public static void main(String[] args) {
	System.out.println("Please the enter the number to find it is strong number or not:");
	Scanner sc=new Scanner(System.in);
	String input=sc.next();
	sc.close();
	int number=Integer.parseInt(input);
	int i,j,x,sum=0,total=0,count=0;
	i=number;
	j=number;
	while(i>0) {
		i=i/10;
		count++;
	}
	System.out.println("count:"+count);
	while(count>0) {
		x=j%10;
		sum=1;
		while(x>0) {
			sum*=x;
			x--;
			//System.out.println("sum:"+sum);
		}
		total+=sum;
		j/=10;
		count--;
	}
	System.out.println("total:"+total);
	System.out.println("number:"+number);
	if(total==number) {
		System.out.println("The Entered number "+number+" is a Strong number");
	}else {
		System.out.println("The Entered number "+number+" is not Strong number");
	}
}
}
