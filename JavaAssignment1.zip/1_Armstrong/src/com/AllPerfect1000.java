package com;

public class AllPerfect1000 {

	public static void main(String[] args) {

		int i,count=0,j=0,sum=0,check,total=0;
		for(i=1;i<1000;i++) {
			check=i;
			sum=0;
			while(check>0) {
				
				if(i%check==0&&i!=check) {
					sum+=check;
				}
				check--;
			}
			if(sum==i) {
				System.out.println(i);
			}
		}

	}

}
