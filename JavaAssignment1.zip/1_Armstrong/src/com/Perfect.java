package com;

import java.util.Scanner;

public class Perfect {

	public static void main(String[] args) {
		System.out.println("Enter the number:");
		Scanner sc = new Scanner(System.in);
		int number=sc.nextInt();
		sc.close();
		int i=1,x,sum=0;
		while(number>i) {
			x=number%i;
			if(x==0) {
				sum+=i;
			}
			i++;
		}
		if(sum == number) {
			System.out.println("the Entered number "+number+" is a Perfect number");
		}else {
			System.out.println("the Entered number "+number+" is not a perfect number");
		}

	}

}
