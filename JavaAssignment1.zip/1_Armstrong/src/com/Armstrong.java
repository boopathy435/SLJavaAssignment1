package com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Armstrong {

	public static void main (String[] args) throws IOException {
		System.out.println("Please enter a number to find if it is a armstrong number or not:\n");
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String input = reader.readLine();
		int number = Integer.parseInt(input);
		int i,j,x,sum = 0,count = 0;
		i=number;
		j=number;
		while(i>0) {
			i=i/10;
			count++;	
		}
		System.out.println("Length of number:"+count);
		while(count>0) {
			x=j%10;
			sum+=Math.pow(x, 3);
			j=j/10;
			count--;
		}
		System.out.println("number input:"+number);
		System.out.println("sum:"+sum);
		if(number==sum) {
			System.out.println("The Entered number "+number+" is a Armstrong number");
		}else {
			System.out.println("The Entered number "+number+" is not a Armstrong number");
		}
		
	}
	
}
